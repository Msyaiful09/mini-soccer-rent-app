<?php

return [
    'merchant_key' => env('MIDTRANS_MERCHANT_KEY'),
    'client_key' => env('MIDTRANS_CLIENT_KEY'),
    'server_key' => env('MIDTRANS_SERVER_KEY'),
];
