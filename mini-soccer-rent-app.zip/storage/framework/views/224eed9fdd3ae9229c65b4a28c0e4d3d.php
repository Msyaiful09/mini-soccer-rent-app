<div class="container-fluid position-relative p-0">
    <nav class="navbar navbar-expand-lg navbar-light px-4 px-lg-5 py-3 py-lg-0">
        <a href="<?php echo e(route('home')); ?>" class="navbar-brand p-0">
            <h1 class="text-primary"><i class="fas fa-futbol me-3"></i>AMC Mini Soccer </h1>
        </a>

        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
            <span class="fa fa-bars"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarCollapse">
            <div class="navbar-nav ms-auto py-0">
                <a href="<?php echo e(route('home')); ?>" class="nav-item nav-link <?php echo e(Request::routeIs('home') ? 'active' : ''); ?>">
                    Beranda
                </a>

                <a href="<?php echo e(route('field')); ?>"
                    class="nav-item nav-link <?php echo e(Request::routeIs('field*') ? 'active' : ''); ?>">
                    Sewa Lapangan
                </a>

                <a href="<?php echo e(route('booked-field')); ?>"
                    class="nav-item nav-link <?php echo e(Request::routeIs('booked-field') ? 'active' : ''); ?>">
                    Lapangan Tersewa
                </a>

                <?php if(auth()->guard()->guest()): ?>
                    <a href="<?php echo e(route('login')); ?>"
                        class="nav-item nav-link d-lg-none <?php echo e(Request::routeIs('login') ? 'active' : ''); ?>">
                        Masuk
                    </a>
                    <a href="<?php echo e(route('register')); ?>"
                        class="nav-item nav-link d-lg-none <?php echo e(Request::routeIs('register') ? 'active' : ''); ?>">
                        Daftar
                    </a>
                <?php endif; ?>

                <?php if(auth()->guard()->check()): ?>
                    <div class="nav-item nav-link d-lg-none fw-bold">
                        Halo, <?php echo e(auth()->user()->name); ?>

                    </div>
                <?php endif; ?>
            </div>
        </div>

        <?php if(auth()->guard()->guest()): ?>
            <div class="d-none d-lg-flex ms-3">
                <a href="<?php echo e(route('login')); ?>" class="btn btn-primary rounded-pill py-2 px-4 me-2">Masuk</a>
                <a href="<?php echo e(route('register')); ?>" class="btn btn-outline-primary rounded-pill py-2 px-4">Daftar</a>
            </div>
        <?php endif; ?>

        <?php if(auth()->guard()->check()): ?>
            <div class="nav-item dropdown d-none d-lg-flex ms-3 align-items-center">
                <a href="#" class="nav-link dropdown-toggle fw-bold" data-bs-toggle="dropdown">
                    Halo, <?php echo e(auth()->user()->name); ?>

                </a>
                <div class="dropdown-menu m-0">

                    <?php if(auth()->user()->role === 'admin'): ?>
                        <a href="<?php echo e(route('admin-dashboard')); ?>"
                            class="dropdown-item <?php echo e(Request::routeIs('admin-dashboard') ? 'active' : ''); ?>">
                            Admin Dashboard
                        </a>
                    <?php elseif(auth()->user()->role === 'customer'): ?>
                        <a href="<?php echo e(route('profile')); ?>"
                            class="dropdown-item <?php echo e(Request::routeIs('profile') ? 'active' : ''); ?>">
                            Profil Saya
                        </a>
                        <a href="<?php echo e(route('rent.index')); ?>"
                            class="dropdown-item <?php echo e(Request::routeIs('rent.index') ? 'active' : ''); ?>">
                            Riwayat Sewa
                        </a>
                    <?php endif; ?>

                    <div class="dropdown-divider"></div>
                    <form action="<?php echo e(route('logout')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="dropdown-item w-100 text-start">Keluar</button>
                    </form>
                </div>
            </div>
        <?php endif; ?>
    </nav>
</div>
<?php /**PATH C:\laragon\www\mini-soccer-rent-app\mini-soccer-rent-app\resources\views/general/partials/navbar.blade.php ENDPATH**/ ?>