
<?php $__env->startSection('container'); ?>
    <div class="container my-5">
        <h2 class="mb-4"><?php echo e($title); ?></h2>
        <div class="alert alert-primary">
            <?php echo e($message); ?>

        </div>
        <a href="<?php echo e(route('home')); ?>" class="btn btn-primary mt-3">Kembali ke Beranda</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('general.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project And Learn\Joki\Program\Rent Website\01 - Mini Soccer Rent\mini-soccer-rent-app\resources\views/general/pages/rent/payment-status.blade.php ENDPATH**/ ?>