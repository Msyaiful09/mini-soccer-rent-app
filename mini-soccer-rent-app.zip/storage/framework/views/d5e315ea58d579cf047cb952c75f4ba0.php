

<?php $__env->startSection('container'); ?>
    <h5 class="mb-3">Kelola Jam Main untuk: <strong><?php echo e($field->name); ?></strong></h5>

    <a href="<?php echo e(route('admin.fields.index')); ?>" class="btn btn-secondary mb-3">Kembali ke Daftar Lapangan</a>
    <div class="mb-3">
        <button class="btn btn-primary" data-toggle="modal" data-target="#addPlayTimeModal">
            Tambah Jam Main
        </button>
    </div>

    <div class="card">
        <div class="card-body">
            <table class="table table-bordered" id="dataTable">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Jam Mulai</th>
                        <th>Jam Selesai</th>
                        <th>Harga</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $playingTimes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $time): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($index + 1); ?></td>
                            <td><?php echo e($time->start_time); ?></td>
                            <td><?php echo e($time->end_time); ?></td>
                            <td>Rp <?php echo e(number_format($time->price, 0, ',', '.')); ?></td>
                            <td>
                                <button class="btn btn-sm btn-warning" data-toggle="modal"
                                    data-target="#editPlayTimeModal<?php echo e($time->id); ?>">Edit</button>
                                <form action="<?php echo e(route('admin.playing-times.destroy', $time->id)); ?>" method="POST"
                                    class="d-inline" onsubmit="return confirm('Yakin ingin menghapus jam main ini?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-sm btn-danger" type="submit">Hapus</button>
                                </form>
                            </td>
                        </tr>

                        <!-- Edit Modal per Jam Main -->
                        <div class="modal fade" id="editPlayTimeModal<?php echo e($time->id); ?>" tabindex="-1" role="dialog"
                            aria-labelledby="editPlayTimeModalLabel<?php echo e($time->id); ?>" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <form action="<?php echo e(route('admin.playing-times.update', $time->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="editPlayTimeModalLabel<?php echo e($time->id); ?>">Edit Jam
                                                Main</h5>
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Tutup">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                        <div class="modal-body">
                                            <div class="mb-3">
                                                <label class="form-label">Jam Mulai</label>
                                                <input type="time" name="start_time" class="form-control"
                                                    value="<?php echo e($time->start_time); ?>" required>
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label">Jam Selesai</label>
                                                <input type="time" name="end_time" class="form-control"
                                                    value="<?php echo e($time->end_time); ?>" required>
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label">Harga</label>
                                                <input type="number" name="price" step="0.01" class="form-control"
                                                    value="<?php echo e($time->price); ?>" required>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <!-- End Modal -->
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Modal Tambah Jam Main -->
    <div class="modal fade" id="addPlayTimeModal" tabindex="-1" role="dialog" aria-labelledby="addPlayTimeModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <form action="<?php echo e(route('admin.fields.playing-times.store', $field->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="addPlayTimeModalLabel">Tambah Jam Main - <?php echo e($field->name); ?></h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Tutup">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">Jam Mulai</label>
                            <input type="time" name="start_time" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Jam Selesai</label>
                            <input type="time" name="end_time" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Harga</label>
                            <input type="number" name="price" step="0.01" class="form-control" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">Tambah Jam Main</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\mini-soccer-rent-app\mini-soccer-rent-app\resources\views/admin/pages/playing-time/index.blade.php ENDPATH**/ ?>