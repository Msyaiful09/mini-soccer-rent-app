<!-- Header Start -->
<div class="container-fluid bg-breadcrumb">
    <div class="container text-center py-5" style="max-width: 900px;">
        <h4 class="text-white display-4 mb-4 wow fadeInDown" data-wow-delay="0.1s"><?php echo e($title); ?></h4>
    </div>
</div>
<!-- Header End -->
<?php /**PATH D:\Project\Joki\Program\Rent-Website\01-Mini Soccer Rent\mini-soccer-rent-app\resources\views/general/partials/header.blade.php ENDPATH**/ ?>