

<?php $__env->startSection('container'); ?>
    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Kode Sewa</th>
                            <th>Penyewa</th>
                            <th>Lapangan</th>
                            <th>Total Harga</th>
                            <th>Jenis Sewa</th>
                            <th>Status</th>
                            <th>Detail Sewa</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $rents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $rent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($index + 1); ?></td>
                                <td><?php echo e($rent->rent_receipt); ?></td>
                                <td><?php echo e($rent->user->name); ?></td>
                                <td><?php echo e($rent->field->name); ?></td>
                                <td>Rp <?php echo e(number_format($rent->total_price, 0, ',', '.')); ?></td>
                                <td>
                                    <?php if($rent->rent_type == 'single'): ?>
                                        <span class="badge badge-info">Sekali</span>
                                    <?php else: ?>
                                        <span class="badge badge-primary">Bulanan</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($rent->status == 'pending'): ?>
                                        <span class="badge badge-warning">Pending</span>
                                    <?php elseif($rent->status == 'paid'): ?>
                                        <span class="badge badge-success">Lunas</span>
                                    <?php else: ?>
                                        <span class="badge badge-danger">Batal</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <button class="btn btn-sm btn-info" data-toggle="modal"
                                        data-target="#rentDetailModal<?php echo e($rent->id); ?>">
                                        Lihat
                                    </button>
                                </td>
                            </tr>

                            <!-- Detail Modal -->
                            <div class="modal fade" id="rentDetailModal<?php echo e($rent->id); ?>" tabindex="-1" role="dialog"
                                aria-labelledby="rentDetailModalLabel<?php echo e($rent->id); ?>" aria-hidden="true">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="rentDetailModalLabel<?php echo e($rent->id); ?>">Detail Sewa
                                            </h5>
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Tutup">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                        <div class="modal-body">
                                            <ul class="list-group">
                                                <?php $__currentLoopData = $rent->rentDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li class="list-group-item">
                                                        Tanggal: <?php echo e($detail->date); ?> <br>
                                                        Jam: <?php echo e($detail->playTime->start_time); ?> -
                                                        <?php echo e($detail->playTime->end_time); ?>

                                                    </li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary"
                                                data-dismiss="modal">Tutup</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- End Modal -->
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\mini-soccer-rent-app\mini-soccer-rent-app\resources\views/admin/pages/rent/index.blade.php ENDPATH**/ ?>