

<?php $__env->startSection('container'); ?>
    <div class="container-fluid">
        <h1 class="h3 mb-4 text-gray-800">Laporan Pendapatan</h1>

        
        <form method="GET" class="mb-4">
            <div class="row">
                <div class="col-md-3">
                    <label>Tahun</label>
                    <select name="year" class="form-control">
                        <?php for($y = date('Y'); $y >= date('Y') - 5; $y--): ?>
                            <option value="<?php echo e($y); ?>" <?php echo e($year == $y ? 'selected' : ''); ?>><?php echo e($y); ?>

                            </option>
                        <?php endfor; ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <label>Bulan (opsional)</label>
                    <select name="month" class="form-control">
                        <option value="">-- Semua Bulan --</option>
                        <?php for($m = 1; $m <= 12; $m++): ?>
                            <option value="<?php echo e($m); ?>" <?php echo e($month == $m ? 'selected' : ''); ?>>
                                <?php echo e(date('F', mktime(0, 0, 0, $m, 1))); ?>

                            </option>
                        <?php endfor; ?>
                    </select>
                </div>
                <div class="col-md-3 align-self-end">
                    <button type="submit" class="btn btn-primary">Filter</button>
                </div>
            </div>
        </form>

        <div class="mb-3">
            <h5>Total Pendapatan: <strong>Rp <?php echo e(number_format($total_income, 0, ',', '.')); ?></strong></h5>
            <a href="<?php echo e(route('admin.income.print-pdf', ['year' => $year, 'month' => $month])); ?>" class="btn btn-danger"
                target="_blank">
                <i class="fas fa-file-pdf"></i> Cetak PDF
            </a>
        </div>


        
        <div class="card">
            <div class="card-body">


                <table class="table table-bordered" id="dataTable">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Tahun</th>
                            <th>Bulan</th>
                            <th>Total Pendapatan (Rp)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $incomes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $income): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($index + 1); ?></td>
                                <td><?php echo e($income->year); ?></td>
                                <td><?php echo e(date('F', mktime(0, 0, 0, $income->month, 1))); ?></td>
                                <td>Rp <?php echo e(number_format($income->total_income, 0, ',', '.')); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <!-- Include DataTables -->
    <script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#dataTable').DataTable();
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\mini-soccer-rent-app\mini-soccer-rent-app\resources\views/admin/pages/income/index.blade.php ENDPATH**/ ?>