

<?php $__env->startSection('container'); ?>
    <div class="mb-3">
        <button class="btn btn-primary" data-toggle="modal" data-target="#addFieldModal">Tambah Lapangan</button>

    </div>

    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama</th>
                            <th>Alamat</th>
                            <th>Deskripsi</th>
                            <th>Gambar</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($index + 1); ?></td>
                                <td><?php echo e($field->name); ?></td>
                                <td><?php echo e($field->address); ?></td>
                                <td><?php echo e($field->description ?? '-'); ?></td>
                                <td>
                                    <?php if($field->image): ?>
                                        <img src="<?php echo e(asset('uploads/fields/' . $field->image)); ?>" width="80">
                                    <?php else: ?>
                                        Tidak ada gambar
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('admin.fields.playing-times.index', $field->id)); ?>"
                                        class="btn btn-sm btn-info" title="Kelola Jam Main">
                                        <i class="fas fa-clock"></i>
                                    </a>

                                    <button class="btn btn-sm btn-warning" data-toggle="modal"
                                        data-target="#editFieldModal<?php echo e($field->id); ?>" title="Edit">
                                        <i class="fas fa-edit"></i>
                                    </button>

                                    <form action="<?php echo e(route('admin.fields.destroy', $field->id)); ?>" method="POST"
                                        class="d-inline" onsubmit="return confirm('Yakin ingin menghapus lapangan ini?')">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button class="btn btn-sm btn-danger" type="submit" title="Hapus">
                                            <i class="fas fa-trash-alt"></i>
                                        </button>
                                    </form>
                                </td>
                            </tr>

                            <!-- Edit Modal -->
                            <div class="modal fade" id="editFieldModal<?php echo e($field->id); ?>" tabindex="-1"
                                aria-labelledby="editFieldModalLabel<?php echo e($field->id); ?>" aria-hidden="true">
                                <div class="modal-dialog">
                                    <form action="<?php echo e(route('admin.fields.update', $field->id)); ?>" method="POST"
                                        enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PUT'); ?>
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title">Edit Lapangan</h5>
                                                <button type="button" class="close" data-dismiss="modal"
                                                    aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="mb-3">
                                                    <label class="form-label">Nama</label>
                                                    <input type="text" name="name" class="form-control"
                                                        value="<?php echo e($field->name); ?>" required>
                                                </div>
                                                <div class="mb-3">
                                                    <label class="form-label">Alamat</label>
                                                    <input type="text" name="address" class="form-control"
                                                        value="<?php echo e($field->address); ?>" required>
                                                </div>
                                                <div class="mb-3">
                                                    <label class="form-label">Deskripsi</label>
                                                    <textarea name="description" class="form-control"><?php echo e($field->description); ?></textarea>
                                                </div>
                                                <div class="mb-3">
                                                    <label class="form-label">Gambar (opsional)</label>
                                                    <input type="file" name="image" class="form-control">
                                                    <?php if($field->image): ?>
                                                        <small class="d-block mt-2">Gambar saat ini:
                                                            <?php echo e($field->image); ?></small>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="modal-footer">

                                                <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                            <!-- End Edit Modal -->
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Modal Tambah Lapangan -->
    <div class="modal fade" id="addFieldModal" tabindex="-1" aria-labelledby="addFieldModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <form action="<?php echo e(route('admin.fields.store')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Tambah Lapangan</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">Nama</label>
                            <input type="text" name="name" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Alamat</label>
                            <input type="text" name="address" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Deskripsi</label>
                            <textarea name="description" class="form-control"></textarea>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Gambar (opsional)</label>
                            <input type="file" name="image" class="form-control">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">Tambah</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project And Learn\Joki\Program\Rent Website\01 - Mini Soccer Rent\mini-soccer-rent-app\resources\views/admin/pages/field/index.blade.php ENDPATH**/ ?>