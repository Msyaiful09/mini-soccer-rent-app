
<?php $__env->startSection('container'); ?>
    <div class="container py-5">
        <h2 class="mb-4"><?php echo e($title); ?></h2>

        <?php if($rents->count()): ?>
            <div class="table-responsive">
                <table class="table table-bordered align-middle">
                    <thead class="table-light">
                        <tr>
                            <th>No</th>
                            <th>No. Nota</th>
                            <th>Lapangan</th>
                            <th>Total Harga</th>
                            <th>Status</th>
                            <th>Tanggal Dibuat</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $rents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($rent->rent_receipt); ?></td>
                                <td><?php echo e($rent->field->name ?? '-'); ?></td>
                                <td>Rp<?php echo e(number_format($rent->total_price, 0, ',', '.')); ?></td>
                                <td>
                                    <?php if($rent->status == 'paid'): ?>
                                        <span class="badge bg-success">Dibayar</span>
                                    <?php elseif($rent->status == 'pending'): ?>
                                        <span class="badge bg-warning text-dark">Menunggu</span>
                                    <?php else: ?>
                                        <span class="badge bg-danger">Dibatalkan</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($rent->created_at->format('d M Y H:i')); ?></td>
                                <td>
                                    <div class="d-flex gap-1 flex-wrap">
                                        <a href="<?php echo e(route('rent.show', $rent->rent_receipt)); ?>"
                                            class="btn btn-sm btn-primary flex-grow-1">
                                            Detail
                                        </a>

                                        <?php if($rent->status === 'pending'): ?>
                                            <form action="<?php echo e(route('rent.cancel', $rent->rent_receipt)); ?>" method="POST"
                                                onsubmit="return confirm('Yakin ingin membatalkan pesanan ini?');"
                                                class="flex-grow-1">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('PUT'); ?>
                                                <button class="btn btn-sm btn-danger w-100">Batalkan</button>
                                            </form>
                                        <?php endif; ?>
                                    </div>
                                </td>

                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <div class="mt-3">
                <?php echo e($rents->links('vendor.pagination.bootstrap-5')); ?>

            </div>
        <?php else: ?>
            <div class="alert alert-info">
                Anda belum memiliki riwayat sewa.
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('general.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\mini-soccer-rent-app\mini-soccer-rent-app\resources\views/general/pages/rent/index.blade.php ENDPATH**/ ?>