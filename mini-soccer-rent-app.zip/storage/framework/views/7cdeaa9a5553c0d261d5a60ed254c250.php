

<?php $__env->startSection('container'); ?>
    <!-- Field Detail Start -->
    <div class="container-fluid about py-5">
        <div class="container py-5">
            <div class="row g-5 align-items-center">

                <!-- Image Section -->
                <div class="col-xl-5 wow fadeInRight" data-wow-delay="0.2s">
                    <div class="position-relative overflow-hidden rounded shadow">
                        <?php if($field->image && file_exists(public_path('uploads/fields/' . $field->image))): ?>
                            <img src="<?php echo e(asset('uploads/fields/' . $field->image)); ?>" class="img-fluid w-100 rounded"
                                alt="<?php echo e($field->name); ?>">
                        <?php else: ?>
                            <img src="<?php echo e(asset('assets/img/field/dummy-field.jpg')); ?>" class="img-fluid w-100 rounded"
                                alt="<?php echo e($field->name); ?>">
                        <?php endif; ?>
                    </div>
                </div>


                <!-- Details Section -->
                <div class="col-xl-7 wow fadeInLeft" data-wow-delay="0.2s">
                    <h4 class="text-primary mb-3">Detail Lapangan</h4>
                    <h1 class="display-5 mb-4"><?php echo e($field->name); ?></h1>

                    <p class="mb-4"><i class="fas fa-map-marker-alt text-primary me-2"></i> <?php echo e($field->address); ?></p>

                    <div class="d-flex align-items-center mb-4">
                        <i class="fas fa-futbol fa-3x text-primary flex-shrink-0"></i>
                        <div class="ms-3">
                            <h4 class="mb-2">Informasi Lapangan</h4>
                            <p class="mb-0"><?php echo e($field->description); ?></p>
                        </div>
                    </div>

                    <a href="#" class="btn btn-primary rounded-pill py-3 px-5 mt-3">Pesan Sekarang</a>
                </div>

            </div>
            <div class="my-5">
                <h4 class="text-primary mb-3">Pilih Waktu Bermain</h4>

                <form method="GET" class="mb-4">
                    <div class="row g-2 align-items-center">
                        <div class="col-auto">
                            <input type="date" id="date" name="date" class="form-control"
                                value="<?php echo e(request('date', now()->addDay()->format('Y-m-d'))); ?>"
                                min="<?php echo e(now()->addDay()->format('Y-m-d')); ?>">
                        </div>
                        <div class="col-auto">
                            <button type="submit" class="btn btn-primary">Lihat</button>
                        </div>
                    </div>
                </form>


                <?php if($selectedDate): ?>
                    <p class="text-muted mb-3">
                        Jadwal untuk hari
                        <?php echo e(\Carbon\Carbon::parse($selectedDate)->locale('id')->isoFormat('dddd, D MMMM Y')); ?>

                    </p>

                    <form action="<?php echo e(route('rent.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="date" value="<?php echo e($selectedDate); ?>">
                        <input type="hidden" name="field_id" value="<?php echo e($field->id); ?>">

                        <div class="mb-3">
                            <label for="rent_type" class="form-label fw-bold">Jenis Sewa</label>
                            <select name="rent_type" id="rent_type" class="form-select" required>
                                <option value="single">Sekali Sewa</option>
                                <option value="monthly">Bulanan (Jadwal sama selama sebulan)</option>
                            </select>
                        </div>

                        <div class="row g-3">
                            <?php $__currentLoopData = $field->playTimes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $time): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $isBooked = $time->rentDetails->isNotEmpty();
                                ?>

                                <div class="col-6 col-sm-4 col-md-3 col-lg-2">
                                    <label
                                        class="playtime-card border rounded p-3 text-center h-100 d-flex flex-column justify-content-between <?php if($isBooked): ?> disabled <?php endif; ?>">
                                        <input type="checkbox" name="play_time_ids[]" value="<?php echo e($time->id); ?>"
                                            <?php if($isBooked): ?> disabled <?php endif; ?>>

                                        <div>
                                            <div class="fw-bold mb-1"><?php echo e($time->start_time); ?> - <?php echo e($time->end_time); ?>

                                            </div>
                                            <?php if($isBooked): ?>
                                                <div class="text-primary fw-semibold">Telah Disewa</div>
                                            <?php else: ?>
                                                <div class="fw-bold mb-2 text-primary">
                                                    Rp<?php echo e(number_format($time->price, 0, ',', '.')); ?>

                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </label>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                        <div class="mt-4">
                            <button type="submit" class="btn btn-primary col-12" disabled id="rentButton">Sewa
                                Sekarang</button>
                        </div>
                    </form>
                <?php else: ?>
                    <p class="text-muted">Pilih tanggal terlebih dahulu.</p>
                <?php endif; ?>
            </div>






        </div>
    </div>
    <!-- Field Detail End -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('general.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\Joki\Program\Rent-Website\01-Mini Soccer Rent\mini-soccer-rent-app\resources\views/general/pages/field/show.blade.php ENDPATH**/ ?>