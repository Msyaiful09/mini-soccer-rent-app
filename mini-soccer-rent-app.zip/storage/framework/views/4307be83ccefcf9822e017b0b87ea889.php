<!-- Copyright Start -->
<div class="container-fluid copyright py-4">
    <div class="container">
        <div class="row g-4 align-items-center">
            <div class="col-md-6 text-center text-md-start mb-md-0">
                <span class="text-body">
                    &copy; <a href="#" class="border-bottom text-white">Mini Soccer Rent</a>. All rights reserved.
                </span>
            </div>
            <div class="col-md-6 text-center text-md-end text-body">
                Developed with ❤️ by <a class="border-bottom text-white" href="https://htmlcodex.com">John Doe</a>
            </div>
        </div>
    </div>
</div>
<!-- Copyright End -->
<?php /**PATH D:\Project And Learn\Joki\Program\Rent Website\01 - Mini Soccer Rent\mini-soccer-rent-app\resources\views/general/partials/copyright.blade.php ENDPATH**/ ?>