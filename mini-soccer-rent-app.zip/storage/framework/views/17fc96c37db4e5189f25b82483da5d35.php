
<?php $__env->startSection('container'); ?>
    <div class="container-fluid service pb-5 mt-5">
        <div class="container pb-5">
            <div class="text-center mx-auto pb-5 wow fadeInUp" data-wow-delay="0.2s" style="max-width: 800px;">
                <h4 class="text-primary">Riwayat Penyewaan</h4>
                <h1 class="display-5 mb-4">Lapangan Yang Sudah Disewa</h1>
                <p>Berikut adalah daftar lapangan yang telah kamu sewa. Klik tombol detail untuk melihat rincian.</p>
            </div>

            <div class="row wow fadeInUp" data-wow-delay="0.3s">
                <div class="col-12">
                    <?php if($rents->isEmpty()): ?>
                        <div class="alert alert-warning text-center">Belum ada data penyewaan.</div>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-bordered table-hover text-center">
                                <thead class="thead-dark">
                                    <tr>
                                        <th>No</th>
                                        <th>Penyewa</th>
                                        <th>Lapangan</th>
                                        <th>Total Harga</th>
                                        <th>Tipe Sewa</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $rents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $rent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($rents->firstItem() + $index); ?></td>
                                            <td><span class="text-success font-weight-bold"><?php echo e($rent->user->name); ?></span>
                                            </td>
                                            <td><?php echo e($rent->field->name); ?></td>
                                            <td>Rp <?php echo e(number_format($rent->total_price, 0, ',', '.')); ?></td>
                                            <td><?php echo e(ucfirst($rent->rent_type)); ?></td>
                                            <td>
                                                <button class="btn btn-sm btn-primary" data-bs-toggle="modal"
                                                    data-bs-target="#detailModal<?php echo e($rent->id); ?>">
                                                    Detail
                                                </button>

                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>

                        <!-- Pagination -->
                        <div class="mt-4 d-flex justify-content-center">
                            <?php echo e($rents->links('vendor.pagination.bootstrap-4')); ?>

                        </div>

                        <!-- All Modals (OUTSIDE TABLE) -->
                        <?php $__currentLoopData = $rents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="modal fade" id="detailModal<?php echo e($rent->id); ?>" tabindex="-1"
                                aria-labelledby="modalLabel<?php echo e($rent->id); ?>" aria-hidden="true">
                                <div class="modal-dialog modal-lg modal-dialog-scrollable">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title">Detail Sewa - #<?php echo e($rent->rent_receipt); ?></h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <?php if($rent->rentDetails->isNotEmpty()): ?>
                                                <table class="table table-sm table-bordered text-center">
                                                    <thead class="thead-light">
                                                        <tr>
                                                            <th>No</th>
                                                            <th>Tanggal</th>
                                                            <th>Jam Main</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php $__currentLoopData = $rent->rentDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <tr>
                                                                <td><?php echo e($i + 1); ?></td>
                                                                <td><?php echo e(\Carbon\Carbon::parse($detail->date)->format('d M Y')); ?>

                                                                </td>
                                                                <td><?php echo e($detail->playTime->start_time ?? '-'); ?> -
                                                                    <?php echo e($detail->playTime->end_time ?? '-'); ?></td>
                                                            </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tbody>
                                                </table>
                                            <?php else: ?>
                                                <p class="text-muted">Tidak ada detail penyewaan.</p>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('general.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\mini-soccer-rent-app\mini-soccer-rent-app\resources\views/general/pages/booked/index.blade.php ENDPATH**/ ?>