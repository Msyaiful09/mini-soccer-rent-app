

<?php $__env->startSection('container'); ?>
    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama</th>
                            <th>Nomor HP</th>
                            <th>Email</th>
                            <th>Role</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($index + 1); ?></td>
                                <td><?php echo e($user->name); ?></td>
                                <td><?php echo e($user->phone_number); ?></td>
                                <td><?php echo e($user->email); ?></td>
                                <td>
                                    <?php if($user->role === 'admin'): ?>
                                        <span class="badge bg-primary text-white">Admin</span>
                                    <?php else: ?>
                                        <span class="badge bg-success text-white">Customer</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <button class="btn btn-sm btn-warning" data-toggle="modal"
                                        data-target="#editUserModal<?php echo e($user->id); ?>">
                                        Edit
                                    </button>
                                </td>
                            </tr>

                            <!-- Edit Modal -->
                            <div class="modal fade" id="editUserModal<?php echo e($user->id); ?>" tabindex="-1"
                                aria-labelledby="editUserModalLabel<?php echo e($user->id); ?>" aria-hidden="true">
                                <div class="modal-dialog">
                                    <form action="<?php echo e(route('admin.users.update', $user->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PUT'); ?>
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="editUserModalLabel<?php echo e($user->id); ?>">Edit
                                                    Pengguna
                                                </h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                    aria-label="Tutup"></button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="mb-3">
                                                    <label for="name<?php echo e($user->id); ?>" class="form-label">Nama</label>
                                                    <input type="text" class="form-control" id="name<?php echo e($user->id); ?>"
                                                        name="name" value="<?php echo e($user->name); ?>" required>
                                                </div>
                                                <div class="mb-3">
                                                    <label for="phone_number<?php echo e($user->id); ?>" class="form-label">Nomor
                                                        HP</label>
                                                    <input type="text" class="form-control"
                                                        id="phone_number<?php echo e($user->id); ?>" name="phone_number"
                                                        value="<?php echo e($user->phone_number); ?>" required>
                                                </div>
                                                <div class="mb-3">
                                                    <label for="email<?php echo e($user->id); ?>" class="form-label">Email</label>
                                                    <input type="email" class="form-control"
                                                        id="email<?php echo e($user->id); ?>" name="email"
                                                        value="<?php echo e($user->email); ?>" required>
                                                </div>
                                                <div class="mb-3">
                                                    <label for="role<?php echo e($user->id); ?>" class="form-label">Role</label>
                                                    <select name="role" id="role<?php echo e($user->id); ?>" class="form-select"
                                                        required>
                                                        <option value="customer"
                                                            <?php echo e($user->role == 'customer' ? 'selected' : ''); ?>>
                                                            Customer</option>
                                                        <option value="admin"
                                                            <?php echo e($user->role == 'admin' ? 'selected' : ''); ?>>Admin
                                                        </option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="close" data-dismiss="modal"
                                                    aria-label="Close">
                                                    <span aria-hidden="true">×</span>
                                                </button>

                                                <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                            <!-- End Modal -->
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\mini-soccer-rent-app\mini-soccer-rent-app\resources\views/admin/pages/users/index.blade.php ENDPATH**/ ?>