

<?php $__env->startSection('container'); ?>
    <div class="container my-5">
        <div class="card shadow rounded-4 p-4 mx-auto" style="max-width: 700px;">
            <h3 class="mb-4 text-center text-primary fw-bold">Invoice Sewa Lapangan</h3>

            <div class="mb-3">
                <div class="d-flex justify-content-between">
                    <span class="text-muted">Kode Invoice</span>
                    <span class="fw-semibold"><?php echo e($rent->rent_receipt); ?></span>
                </div>
                <div class="d-flex justify-content-between">
                    <span class="text-muted">Nama Lapangan</span>
                    <span class="fw-semibold"><?php echo e($rent->field->name); ?></span>
                </div>
                <div class="d-flex justify-content-between">
                    <span class="text-muted">Jenis Sewa</span>
                    <span class="fw-semibold text-capitalize"><?php echo e($rent->rent_type); ?></span>
                </div>
                <div class="d-flex justify-content-between">
                    <span class="text-muted">Status</span>
                    <span
                        class="badge 
                        <?php if($rent->status == 'paid'): ?> bg-success 
                        <?php elseif($rent->status == 'pending'): ?> bg-warning text-dark 
                        <?php elseif($rent->status == 'canceled'): ?> bg-danger <?php endif; ?>">
                        <?php echo e(ucfirst($rent->status)); ?>

                    </span>
                </div>
            </div>

            <hr>

            <h5 class="fw-bold mb-3">Detail Waktu Sewa:</h5>

            <?php
                $detailsByDate = $rent->rentDetails->groupBy('date');
            ?>

            <?php $__currentLoopData = $detailsByDate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date => $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="mb-3">
                    <h6 class="fw-bold mb-2">Tanggal: <?php echo e(\Carbon\Carbon::parse($date)->format('d M Y')); ?></h6>
                    <ul class="list-group">
                        <?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-group-item d-flex justify-content-between">
                                <span><?php echo e($detail->playTime->start_time); ?> - <?php echo e($detail->playTime->end_time); ?></span>
                                <span>Rp<?php echo e(number_format($detail->playTime->price, 0, ',', '.')); ?></span>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <div class="d-flex justify-content-between fs-5 fw-bold mt-4">
                <span>Total Harga</span>
                <span class="text-primary">Rp<?php echo e(number_format($rent->total_price, 0, ',', '.')); ?></span>
            </div>

            <div class="d-grid gap-2 mt-4">
                <a href="<?php echo e(route('home')); ?>" class="btn btn-outline-secondary">
                    Kembali ke Beranda
                </a>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('general.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\mini-soccer-rent-app\mini-soccer-rent-app\resources\views/general/pages/rent/invoice.blade.php ENDPATH**/ ?>