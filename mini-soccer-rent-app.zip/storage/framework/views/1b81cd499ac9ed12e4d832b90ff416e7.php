
<?php $__env->startSection('container'); ?>
    <div class="row">
        <div class="col-md-3 mb-4">
            <div class="card shadow h-100 text-center">
                <div class="card-body d-flex flex-column justify-content-center">
                    <h5 class="card-title">Total Pengguna</h5>
                    <h3 class="text-primary"><?php echo e($totalUsers); ?></h3>
                    <small><?php echo e($totalCustomers); ?> Customer, <?php echo e($totalAdmins); ?> Admin</small>
                </div>
            </div>
        </div>

        <div class="col-md-3 mb-4">
            <div class="card shadow h-100 text-center">
                <div class="card-body d-flex flex-column justify-content-center">
                    <h5 class="card-title">Total Lapangan</h5>
                    <h3 class="text-success"><?php echo e($totalFields); ?></h3>
                    <small><?php echo e($totalPlayTimes); ?> Jam Main</small>
                </div>
            </div>
        </div>

        <div class="col-md-3 mb-4">
            <div class="card shadow h-100 text-center">
                <div class="card-body d-flex flex-column justify-content-center">
                    <h5 class="card-title">Total Sewa</h5>
                    <h3 class="text-warning"><?php echo e($totalRents); ?></h3>
                    <small><?php echo e($pendingRents); ?> Menunggu</small>
                </div>
            </div>
        </div>

        <div class="col-md-3 mb-4">
            <div class="card shadow h-100 text-center">
                <div class="card-body d-flex flex-column justify-content-center">
                    <h5 class="card-title">Total Pendapatan</h5>
                    <h3 class="text-success">Rp<?php echo e(number_format($totalRevenue, 0, ',', '.')); ?></h3>
                    <small>Dari transaksi yang sudah dibayar</small>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\mini-soccer-rent-app\mini-soccer-rent-app\resources\views/admin/pages/home/index.blade.php ENDPATH**/ ?>